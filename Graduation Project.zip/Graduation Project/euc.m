clear all
close all
clc

tic
images = 10;
train_images=9;
test_images=10;
np= 30;
counter = 1;

path = './sub/';
fullfile(path);
% Loop for train images
for i = 1:np
    for j = 1:train_images
        file_path = strcat(fullfile(path), 'face', num2str(i), 'L', num2str(j), '.bmp');
        img = imread(file_path);
        combined_vectors(:, counter) =img(:);
        counter = counter + 1;
    end
end
counter=1;
%loop for test image
   for i=1:np
       for j=images:images
          a=strcat(fullfile(path),'face',num2str(i),'L',num2str(j),'.bmp');
         img=imread(a);
           combined_vectors_test(:,counter)=img(:);
           counter = counter + 1;
      end
   end
mean_vector=(sum(combined_vectors')')/(np*images);
mn_1s=ones(np*train_images,1);
%extracting train faces features
m_matrix=(mn_1s*(mean_vector)')';
covariance_matrix = double(combined_vectors)- m_matrix;
co_tr=(covariance_matrix)'*covariance_matrix;
[eigen_vectors, eigen_values] = eig(co_tr);
[s1,s2]= size(eigen_vectors);
diagonal_eigen_v= diag(eigen_values); 
V=ones(s1,1);
eg_values=(V*(diagonal_eigen_v)');
sq=sqrt(eg_values);
points= (eigen_vectors)./(sq);
feature_train=covariance_matrix*points;
final_feature=(feature_train)'* double(covariance_matrix);
%extracting test faces features
test_o=ones(np*(images-train_images),1);
mn_t=(test_o*mean_vector')';
cov_test=double(combined_vectors_test)-mn_t;
feature_test=feature_train'*double(cov_test);
% store classification results




filename = 'correct.xlsx';
sheetname3='Sheet1';
irisclass= xlsread(filename,sheetname3);

ty=feature_test';
tx=final_feature';
T=0.5;
fr=0;
fa=0;
rrate=[];
ecdist=0;
NTrainingSamples=9;
for ntr=1:NTrainingSamples
 for itr=1:1
   for q=1:size(ty,1)
       for k=1:size(tx,1)        
            ecdist(k,:)=abs(sqrt(sum(((ty(q,:))- (tx(k,:))).^2))); 
       end
       [r tt]=min(ecdist);
       mn(q)=ceil(tt/ntr);
       tty(q)=r;
       R=max(tty,[],2);
       tf=tty./R;

     
       correct1=find(tf>=T);
       correct1=correct1';
      
   end
answer=mn';
correct = find( irisclass - answer == 0);
Euc_L2(itr)= 100*size(correct1,1) / size(answer,1);
 end
rrate =[rrate; ntr mean([ Euc_L2' ])];
end

fr=0;
fa=0;
for i=1:np
    if (tf(i)>T)
        fa=fa+1;
    else 
        fr=fr+1;
    end
end
frr=(fr/(9*(np*9)))*100;
far=(fa/((9*np)*((9*np)-9)))*100;
TT=[ 0.1 0.2 0.3 0.4 0.5 0.6 ];

regE=[100 100 100 90 80 40 ];
farx=[0.0426 0.0426 0.0426 0.0383 0.0341 0.0170 ];
frrx=[0 0 0 0.1235 0.2469 0.7407];



%regE=[100 100 97.5 87.5 77.5 45 ];
%farx=[0.0317 0.0317 0.0309 0.0277 0.0245 0.142 ];
%frrx=[0 0 0.0309 0.1543 0.2778 0.6790];

toc