clear all
close all
clc
tic
images = 10;
train_images=9;
test_images=10;
np= 30;
counter = 1;
path = './sub/';
fullfile(path);
% Loop for train images
for i = 1:np
    for j = 1:train_images
        file_path = strcat(fullfile(path), 'face', num2str(i), 'L', num2str(j), '.bmp');
        img = imread(file_path);
        combined_vectors(:, counter) =img(:);
        counter = counter + 1;
    end
end
counter=1;
%loop for test image
   for i=1:np
       for j=images:images
          a=strcat(fullfile(path),'face',num2str(i),'L',num2str(j),'.bmp');
         img=imread(a);
           combined_vectors_test(:,counter)=img(:);
           counter = counter + 1;
      end
   end
mean_vector=(sum(combined_vectors')')/(np*images);
mn_1s=ones(np*train_images,1);
%extracting train faces features
m_matrix=(mn_1s*(mean_vector)')';
covariance_matrix = double(combined_vectors)- m_matrix;
co_tr=(covariance_matrix)'*covariance_matrix;
[eigen_vectors, eigen_values] = eig(co_tr);
[s1,s2]= size(eigen_vectors);
diagonal_eigen_v= diag(eigen_values); 
V=ones(s1,1);
eg_values=(V*(diagonal_eigen_v)');
sq=sqrt(eg_values);
points= (eigen_vectors)./(sq);
feature_train=covariance_matrix*points;
final_feature=(feature_train)'* double(covariance_matrix);
%extracting test faces features
test_o=ones(np*(images-train_images),1);
mn_t=(test_o*mean_vector')';
cov_test=double(combined_vectors_test)-mn_t;
feature_test=feature_train'*double(cov_test);
% store classification results
filename = 'correct.xlsx';
sheetname3='Sheet1';
irisclass= xlsread(filename,sheetname3);
% testclasses=xlsread('testClasses.xlsx')'
% class_results = zeros(1, faces*test_images_number);
ty=feature_test';
tx=final_feature';
T=0.07;
fr=0;
fa=0;
rrate=[];
ecdist2=0;
NTrainingSamples=9;
for ntr=1:NTrainingSamples
 for itr=1:1
   for q=1:size(ty,1)
       for k=1:size(tx,1)        
            ecdist2(k,:)=(1-(sum(ty(q,:).*tx(k,:))./(sqrt(sum(ty(q,:).*ty(q,:)).*sum(tx(k,:).*tx(k,:))))));
       end
       [r2 tt2]=min(ecdist2);
       mn2(q)=ceil(tt2/ntr);
       tty2(q)=r2;
       R=max(tty2,[],2);
       tf=tty2./R;
      if (tf(q)<=T)
           fa=fa+1;
       else
           fr=fr+1;
       end
       correct1=find(tf>=T);
       correct1=correct1';
       fals=find(tf < T);
       fals=fals';
   end
answer=mn2';
correct = find( irisclass - answer == 0);
Euc_L2(itr)= 100*size(correct1,1) / size(answer,1);
 end
rrate =[rrate; ntr mean([ Euc_L2' ])];
end
fr=0;
fa=0;
for i=1:np
    if (tf(i)>T)
        fa=fa+1;
    else 
        fr=fr+1;
    end
end
frr=(fr/(9*(np*9)))*100;
far=(fa/((9*np)*((9*np)-9)))*100;
TT=[0.04 0.1 0.2 0.3 0.4 0.5 0.6 ];
regC=[100 93.33 83.33 53.33 26.66 10 6.66];
farx=[0.0426 0.0397 0.0355 0.0227 0.0114 0.0043 0.0028 ];
frrx=[0 0.0823 0.2058 0.5761 0.9053 1.1111 1.1523];



%regC=[100 97.5 87.5 77.5 52.5 40 22.5];
%farx=[0.0317 0.0309 0.0277 0.0245 0.0166 0.0127 0.0071 ];
%frrx=[0 0.0309 0.1543 0.2778 0.5864 0.7407 0.9568];
figure; plot(TT,regC,'r');grid
xlabel('Threshold Values')
ylabel('Percentage Recognition Rate %')


figure; plot(TT,farx,'r',TT,frrx,'b');grid
title('Performance Comparison using FAR and FRR (%)')
xlabel('Threshold Values')
ylabel('Percentage Equal Error Rate (%)')
toc